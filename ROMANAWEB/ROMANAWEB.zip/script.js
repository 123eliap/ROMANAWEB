function saludar() {
  alert('¡Hola! Esto está funcionando bien.');
}
